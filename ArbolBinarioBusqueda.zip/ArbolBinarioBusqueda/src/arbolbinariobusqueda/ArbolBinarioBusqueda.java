/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolbinariobusqueda;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import java.util.LinkedList;
import java.util.Random;


import javax.swing.JOptionPane;

/**
 *
 * @author jorge
 */
public class ArbolBinarioBusqueda {
    
public static ArrayList<Integer> generarAleatoriosNoRepetidos (int cantidad) {
		ArrayList<Integer> respuesta = new ArrayList<>();
		for (int i = 0; i < cantidad; i++) {
			respuesta.add(gen(respuesta));
		}			
		return respuesta;
	}
    
   public static int gen(ArrayList<Integer>a) {
		Random ra = new Random();	
		int numero = ra.nextInt(1000);
		if (!a.contains(numero)) {
			return numero;
		}else {
			return gen(a);
		}
	}
public static void imprimir (ArrayList<Integer>num) {
		for (int i = 0; i < num.size(); i++) {
			System.out.println(num.get(i));
		}
	}

    
    public static final String SEPARADOR = ",";
    static long tiempoInicio;
    static long tiempoFinal;
    static long tiempo;
  
    public static void main(String[] args) throws IOException {
      
       LinkedList<String> ciudades= new LinkedList<String>();
       Integer[] numeros=new Integer[generarAleatoriosNoRepetidos(1000).size()];
         numeros= generarAleatoriosNoRepetidos(1000).toArray(numeros);
       
      
     
         Arbol arbol=new Arbol ();
     
        BufferedReader bufferLectura = null;
        
 
 try {
  // Abrir el .csv en buffer de lectura
  bufferLectura = new BufferedReader(new FileReader("C:\\Users\\jorge\\Documents\\NetBeansProjects\\ArbolBinarioBusqueda\\ciudades_del_mundo.csv"));
  
  // Leer una linea del archivo
  String linea = bufferLectura.readLine();
  
  while ((linea = bufferLectura.readLine())!= null) {
   // Separar la linea leída con el separador definido previamente
   ciudades.add(linea);
 
   // Volver a leer otra línea del fichero
   linea = bufferLectura.readLine();
   
   
  }
 } 
 catch (IOException e) {
 }
 finally {
  // Cierro el buffer de lectura
  if (bufferLectura != null) {
   try {
    bufferLectura.close();
   } 
   catch (IOException e) {
   }
  }
  
String[] random= new String[1000];
  for (int i = 0; i < 1000; i++) {
    random[i]=(ciudades.get((int) (Math.floor(Math.random() * ((ciudades.size() - 1) - 0 + 1) + 0))));
  arbol.Agregar(numeros[i], random[i]);
}
 
              int opc=0; int objeto;
        String ciudad;
       
        do{
            try{
                opc=Integer.parseInt(JOptionPane.showInputDialog(null,"1. Insercion\n"
                        + "2. Eliminacion\n"
                        + "3. Busqueda\n"
                        + "4. Recorrer el arbol de forma previa\n"
                        + "5. Recorrer el arbol de forma simetrica\n"
                        + "6. Recorrer el arbol de forma posterior\n"
                        + "7. Salir\n"
                        + "Ingrese una opcion","Arbol Binario",JOptionPane.QUESTION_MESSAGE));
                switch(opc){
                    case 1:
                        objeto=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el numero del Nodo: ","Agregando",JOptionPane.QUESTION_MESSAGE));
                        ciudad =JOptionPane.showInputDialog(null,"Ingresa el nombre de la ciudad","Agregando",JOptionPane.QUESTION_MESSAGE);
                       arbol.Agregar(objeto, ciudad);
                       JOptionPane.showMessageDialog(null, "El nodo ha sido agregado exitosamente ");
                        break;
                        
                    case 2:
                        
                        if(!arbol.estaVacio()){
                            tiempoInicio = System.currentTimeMillis();
                           objeto=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el numero del nodo a eliminar: ","Eliminando"
                                   ,JOptionPane.QUESTION_MESSAGE));
                           
                           
                           if(arbol.eliminar(objeto)==false){
                               JOptionPane.showMessageDialog(null, "El nodo no existe ");
                                tiempoFinal = System.currentTimeMillis();
                                 tiempo=tiempoFinal-tiempoInicio;
                                 System.out.println("Tiempo de ejecucuion en milisegundos: "+tiempo);
                           }
                           else{
                                JOptionPane.showMessageDialog(null, "El nodo ha sido eliminado exitosamente ");
                               tiempoFinal = System.currentTimeMillis();
                                 tiempo=tiempoFinal-tiempoInicio;
                                 System.out.println("Tiempo de ejecucuion en milisegundos: "+tiempo);
                           }
                        } else{
                            JOptionPane.showMessageDialog(null, "El arbol esta vacio ");
                        }
                        
                 
                        break;
                    case 3:
                        
                         if(!arbol.estaVacio()){
                             tiempoInicio = System.currentTimeMillis();
                           objeto=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el numero del nodo a buscar: ","Buscando"
                                   ,JOptionPane.QUESTION_MESSAGE));
                           int cont=0;
                           for(int i=0; i<1000;i++){
                               if(objeto!=numeros[i]){
                                   cont++;
                                   
                               } else if(objeto==numeros[i]){
                               break;    
                               }
                             
                           }
                           if(arbol.buscar(objeto)==null){
                               JOptionPane.showMessageDialog(null, "El nodo no existe ");
                           }
                           
                           else{
                               System.out.println("Nodo encontrado: "+arbol.buscar(objeto));
                                tiempoFinal = System.currentTimeMillis();
                                 tiempo=tiempoFinal-tiempoInicio;
                                 System.out.println("Tiempo de ejecucuion en milisegundos: "+tiempo);
                                 System.out.println("El numero de comparaciones fue: "+cont);
                           }
                        } else{
                            JOptionPane.showMessageDialog(null, "El arbol esta vacio ");
                        }
                        
                           
                        break;
                    case 4:
                         System.out.println();
                        System.out.println("Forma previa: ");
                        System.out.println();
                        if(!arbol.estaVacio()){
                            arbol.previo(arbol.raiz);
                        } else{
                            JOptionPane.showMessageDialog(null, "El arbol esta vacio ");
                        }
                      
                        
                        break;
                    case 5:
                         System.out.println();
                         System.out.println("Forma simetrica: ");
                        System.out.println();
                         
                          if(!arbol.estaVacio()){
                            arbol.simetrico(arbol.raiz);
                        } else{
                            JOptionPane.showMessageDialog(null, "El arbol esta vacio ");
                        }
                        
                   
                       
                        break;
                    case 6:
                         System.out.println();
                         System.out.println("Forma posterior: ");
                        System.out.println();
                        if(!arbol.estaVacio()){
                            arbol.posterior(arbol.raiz);
                        } else{
                            JOptionPane.showMessageDialog(null, "El arbol esta vacio ");
                        }
                     
                        
                        break;
                    case 7:
                      
                        JOptionPane.showMessageDialog(null, "Finalizado con exito","Saliendo...",JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opcion erronea","Error",JOptionPane.INFORMATION_MESSAGE);
                }
               
            } catch(NumberFormatException n){
                JOptionPane.showMessageDialog(null, "ERROR "+n.getMessage());
            }
        } while(opc!=7);
        
        
    }

    
   
    
}
   
  
}

