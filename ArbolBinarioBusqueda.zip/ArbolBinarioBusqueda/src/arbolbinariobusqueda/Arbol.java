/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolbinariobusqueda;

import java.util.Map;

/**
 *
 * @author jorge
 */
public class Arbol {
    
    Nodo raiz;
    public Arbol(){
        raiz=null;
    }

    Arbol(Map<Integer, String> map) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    /*
    Metodo para insertar un nodo en el arbol
    */
    public void Agregar(int d, String Nom){
        Nodo nuevo= new Nodo(d,Nom);
       
        if(raiz==null){
            raiz=nuevo;
        } else{
            Nodo aux=raiz;
            Nodo padre;
            while(true){
                padre=aux;
                if(d<aux.dato){
                    aux=aux.izquiero;
                    if(aux==null){
                        padre.izquiero=nuevo;
                        return;
                    }
                } else{
                    aux=aux.derecho;
                    if(aux==null){
                        padre.derecho=nuevo;
                        return;
                    }
                }
            }
            
        }
        
    }
    /*
    Metodo para verificar si el arbol esta vacio
    */
    public boolean estaVacio(){
        return raiz==null;
    }
   
    /*
    Metodo para recorrer el arbol de forma simetrica
    */
    public synchronized void simetrico(Nodo raiz){
        if(raiz!=null){
            simetrico(raiz.izquiero);
            System.out.println(raiz.toString());
            simetrico(raiz.derecho);
        }
       
    }
    /*
    Metodo para recorrer el arbol de forma previa
    */
     public synchronized void previo(Nodo raiz){
        if(raiz!=null){
            System.out.println(raiz.toString());
            previo(raiz.izquiero);
            previo(raiz.derecho);
        }
    }
       /*
    Metodo para recorrer el arbol de forma posterior
    */
     public synchronized void posterior(Nodo raiz){
        if(raiz!=null){
            posterior(raiz.izquiero);
            posterior(raiz.derecho);
            System.out.println(raiz.toString());
        }
    }
     /*
     Metodo para buscar
     */
     public Nodo buscar(int d){
         
         Nodo aux=raiz;
         while(aux.dato!=d){
             
             if(d<aux.dato){
                 aux=aux.izquiero;
             } else{
                 aux=aux.derecho;
             }
             if(aux==null){
                 return null;
             }
         } 
         
         
           
         return aux;
        
         
     
     }
     
     /*
Metodo para eliminar
*/
     
     public boolean eliminar(int d){
    Nodo aux=raiz;
        Nodo padre=raiz;
        boolean hijoIzq=true;
        while(aux.dato!=d){
            padre=aux;
            if(d<aux.dato){
                hijoIzq=true;
                aux=aux.izquiero;
            } else{
                hijoIzq=false;
                aux=aux.derecho;
            } if(aux==null){
                return false;
            }
        } 
        if(aux.izquiero==null&&aux.derecho==null){
            if(aux==raiz){
                raiz=null;
            } else if(hijoIzq){
                padre.izquiero=null;
            } else{
                padre.derecho=null;
            } 
        } else if(aux.derecho==null){
            if(aux==raiz){
                raiz=aux.izquiero;
            } else if(hijoIzq){
                padre.izquiero=aux.izquiero;
            } else{
                padre.derecho=aux.derecho;
            } 
        } 
        else if(aux.izquiero==null){
            if(aux==raiz){
                raiz=aux.derecho;
            } else if(hijoIzq){
                padre.izquiero=aux.derecho;
            } else{
                padre.derecho=aux.derecho;
            } 
        }
        else{
            Nodo cambiar=getNodoCambiar(aux);
            if(aux==raiz){
                raiz=cambiar;
            } else if(hijoIzq){
                padre.izquiero=cambiar;
            } else{
                padre.derecho=cambiar;
            } cambiar.izquiero=aux.izquiero;
        } return true;
}
     /*
     Metodo para obtener el nodo a cambiar
     */
     
    public Nodo getNodoCambiar(Nodo nodoCambio){
    Nodo cambiarPadre=nodoCambio;
    Nodo cambio=nodoCambio;
    Nodo aux= nodoCambio.derecho;
    while(aux!=null){
        cambiarPadre=cambio;
        cambio=aux;
        aux=aux.izquiero;
    }
    if(cambio!=nodoCambio.derecho){
        cambiarPadre.izquiero=cambio.derecho;
        cambio.derecho=nodoCambio.derecho;
        
    }
        System.out.println("El nodo cambiado es: "+cambio);
    return cambio;
     }
     
}

